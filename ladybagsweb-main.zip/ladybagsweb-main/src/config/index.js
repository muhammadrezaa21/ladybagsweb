export const host_url = "http://localhost:4000";
export const host_url_api = "http://localhost:4000/api/v1/";
