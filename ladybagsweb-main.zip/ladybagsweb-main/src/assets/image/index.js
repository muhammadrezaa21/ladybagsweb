import TentangKami1 from "./tentangkami1.jpg";
import TentangKami2 from "./tentangkami2.jpg";
import TentangKami3 from "./tentangkami3.jpg";

export { TentangKami1, TentangKami2, TentangKami3 };
